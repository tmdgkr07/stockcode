"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const src_1 = require("../src");
const prefix = '>';
const server = new src_1.UDPServer();
server.once('ready', (port) => {
    console.log(`Server ready on port ${port}!`);
});
server.on('chat', (msg) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    if (!msg.content.startsWith(prefix))
        return;
    const args = msg.content.split(' ');
    const cmd = (_a = args.shift()) === null || _a === void 0 ? void 0 : _a.slice(prefix.length);
    if (cmd === 'ping') {
        /*
          this command's result is the ping between Node.js and MessengerBot,
          not between MessengerBot and the KakaoTalk server.
        */
        const timestamp = Date.now();
        yield msg.replyText('Pong!');
        msg.replyText(`${Date.now() - timestamp}ms`);
    }
}));
server.start();
