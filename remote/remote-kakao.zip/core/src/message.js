"use strict";
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _Message_server, _Message_info;
Object.defineProperty(exports, "__esModule", { value: true });
exports.Message = void 0;
class Message {
    constructor(server, info, data) {
        _Message_server.set(this, void 0);
        _Message_info.set(this, void 0);
        __classPrivateFieldSet(this, _Message_server, server, "f");
        __classPrivateFieldSet(this, _Message_info, info, "f");
        this.room = {
            name: data.room,
            id: data.chatId,
            isGroupChat: data.isGroupChat,
        };
        this.id = data.logId;
        this.sender = data.sender;
        this.content = data.content;
        this.app = {
            packageName: data.packageName,
            userId: data.userId,
        };
    }
    replyText(text, timeout = 60000) {
        return __classPrivateFieldGet(this, _Message_server, "f").sendText(__classPrivateFieldGet(this, _Message_info, "f"), this.room.id, text, timeout);
    }
}
exports.Message = Message;
_Message_server = new WeakMap(), _Message_info = new WeakMap();
